/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;

int main()
{
    int size = 5;
    int battery[size];
    
    cout << " Battery Inputs: ";
    
    for (int index = 0; index < size; index++)
    {
        cin >> battery[index];
    }
    
    cout << " Battery: ";
    for (int index = 0; index < size; index++)
    {
        cout << battery[index] << " ";
    }
    cout << endl;
    
    int low_count = 0;
    
    for ( int index = 0; index < size; index++ )
    {
        if (battery[index] < 20 )
        {
            low_count++;
        }
    }
    
    cout << " Low Readings ( < 20% ): " << low_count;
    return 0;
}