/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;

int main()
{
    int size = 5;
    int cost[size];
    
    cout << " Enter Fuel Cost: ";
    
    for ( int index = 0; index < size; index++)
    {
        cin >> cost[index];
    }

cout << " Cost: ";

for ( int index = 0; index < size; index ++)
{
    cout << cost[index] << " ";
}

cout << endl;

int max_cost = cost[0];

for ( int index = 1; index < size; index++ )
{
    if ( cost[index] > max_cost)
    {
        max_cost = cost[index];
    }
}
    
cout <<" Highest cost: " << max_cost << endl;
    return 0;
}